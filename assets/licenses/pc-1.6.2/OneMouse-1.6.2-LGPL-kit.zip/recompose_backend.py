"""Recompose the OneMouse 1.6.2 backend with a user-modified zeroconf.

This is a separate LGPL compliance utility, not code loaded by the released app.
Only the zeroconf package is replaced; other embedded object-code bytes are copied.
Requires 64-bit CPython 3.11. No third-party Python packages are required.

Copyright (c) 2026 OneMouse contributors
SPDX-License-Identifier: MIT
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import marshal
from pathlib import Path
import struct
import sys
import zlib


BASE_SHA256 = "9bee371c5d944d754eb97f7722d7aa5ae702570380899b0ffe8a091edb3d0ae2"
COOKIE = struct.Struct("!8sIIII64s")
COOKIE_MAGIC = b"MEI\x0c\x0b\x0a\x0b\x0e"
TOC_HEADER = struct.Struct("!IIIIBc")
LIBRARY = "zeroconf"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def base_from_manifest(path: Path) -> bytes:
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest["sha256"].lower() != BASE_SHA256:
        raise ValueError("This utility supports only the recorded OneMouse 1.6.2 backend.")
    chunks = []
    for part in manifest["parts"]:
        name = part["filename"]
        if Path(name).name != name:
            raise ValueError("Part filenames must be simple filenames beside the manifest.")
        data = (path.parent / name).read_bytes()
        if len(data) != part["bytes"] or digest(data) != part["sha256"].lower():
            raise ValueError(f"Part failed its recorded size/SHA-256 check: {name}")
        chunks.append(data)
    result = b"".join(chunks)
    if len(result) != manifest["bytes"]:
        raise ValueError("Combined object-code length differs from the manifest.")
    return result


def read_archive(data: bytes):
    cookie_at = data.rfind(COOKIE_MAGIC)
    if cookie_at < 0 or cookie_at + COOKIE.size != len(data):
        raise ValueError("Expected an unsigned PyInstaller executable ending at its archive cookie.")
    magic, size, toc_at, toc_size, py_version, py_library = COOKIE.unpack_from(data, cookie_at)
    start = cookie_at + COOKIE.size - size
    if magic != COOKIE_MAGIC or start < 0 or toc_at + toc_size != size - COOKIE.size:
        raise ValueError("Invalid PyInstaller archive boundaries.")
    if py_version != 311:
        raise ValueError("The supplied backend must contain CPython 3.11 object code.")
    entries = []
    pos, end = start + toc_at, start + toc_at + toc_size
    while pos < end:
        entry_size, offset, size_on_disk, raw_size, compressed, kind = TOC_HEADER.unpack_from(data, pos)
        if entry_size < TOC_HEADER.size + 1 or pos + entry_size > end:
            raise ValueError("Invalid archive table entry.")
        name = data[pos + TOC_HEADER.size : pos + entry_size].rstrip(b"\0").decode("utf-8")
        if offset + size_on_disk > toc_at:
            raise ValueError("Archive member overlaps its table.")
        payload = data[start + offset : start + offset + size_on_disk]
        entries.append((name, payload, raw_size, compressed, kind))
        pos += entry_size
    return data[:start], entries, py_version, py_library


def uncompressed(entry) -> bytes:
    data = zlib.decompress(entry[1]) if entry[3] else entry[1]
    if len(data) != entry[2]:
        raise ValueError(f"Invalid uncompressed member length: {entry[0]}")
    return data


def encode_archive(prefix: bytes, entries, py_version: int, py_library: bytes) -> bytes:
    payload = bytearray()
    toc = bytearray()
    for name, data, raw_size, compressed, kind in entries:
        encoded_name = name.encode("utf-8") + b"\0"
        entry_size = (TOC_HEADER.size + len(encoded_name) + 15) // 16 * 16
        toc.extend(TOC_HEADER.pack(entry_size, len(payload), len(data), raw_size, compressed, kind))
        toc.extend(encoded_name.ljust(entry_size - TOC_HEADER.size, b"\0"))
        payload.extend(data)
    toc_at = len(payload)
    payload.extend(toc)
    payload.extend(COOKIE.pack(COOKIE_MAGIC, len(payload) + COOKIE.size, toc_at, len(toc), py_version, py_library))
    return prefix + payload


def replacement_pyz(pyz: bytes, source_dir: Path):
    if pyz[:4] != b"PYZ\0" or pyz[4:8] != importlib.util.MAGIC_NUMBER:
        raise ValueError("PYZ bytecode magic differs. Use CPython 3.11, not Python 3.12/3.13.")
    toc_at = struct.unpack_from("!i", pyz, 8)[0]
    original_toc = list(dict(marshal.loads(pyz[toc_at:])).items())
    sources = {}
    source_dir = source_dir.resolve(strict=True)
    if not (source_dir / "__init__.py").is_file():
        raise ValueError("--zeroconf-dir must point to the zeroconf package containing __init__.py.")
    for path in sorted(source_dir.rglob("*.py")):
        path.resolve(strict=True).relative_to(source_dir)
        relative = path.relative_to(source_dir)
        if "__pycache__" in relative.parts:
            continue
        parts = (LIBRARY, *relative.with_suffix("").parts)
        is_package = parts[-1] == "__init__"
        module_name = ".".join(parts[:-1] if is_package else parts)
        data = path.read_bytes()
        code = compile(data, f"zeroconf/{relative.as_posix()}", "exec", dont_inherit=True)
        sources[module_name] = (1 if is_package else 0, zlib.compress(marshal.dumps(code), 6), digest(data))
    if not sources:
        raise ValueError("No replacement Python source files found.")

    # Preserve every unrelated bytecode payload exactly, without decompiling it.
    result = bytearray(pyz[:17])
    new_toc = []
    for name, (kind, offset, size) in original_toc:
        if name == LIBRARY or name.startswith(LIBRARY + "."):
            continue
        new_toc.append((name, (kind, len(result), size)))
        result.extend(pyz[offset : offset + size])
    for name, (kind, payload, _) in sorted(sources.items()):
        new_toc.append((name, (kind, len(result), len(payload))))
        result.extend(payload)
    struct.pack_into("!i", result, 8, len(result))
    result.extend(marshal.dumps(new_toc))
    return bytes(result), {name: value[2] for name, value in sources.items()}


def probe_entry():
    # The probe exits before the proprietary application's entry point. It imports
    # the actual replacement package and exercises data-only APIs, with no socket,
    # login, pairing, discovery, settings, or background app processes started.
    source = '''import json
import sys
import zeroconf
import zeroconf._cache
info = zeroconf.ServiceInfo("_onemouse._tcp.local.", "LGPL probe._onemouse._tcp.local.", addresses=[b"\\x7f\\x00\\x00\\x01"], port=5000)
cache = zeroconf._cache.DNSCache()
print(json.dumps({"version": zeroconf.__version__, "marker": getattr(zeroconf, "__onemouse_relink_probe__", None), "cache_marker": getattr(zeroconf._cache, "__onemouse_relink_probe__", None), "service_port": info.port, "empty_cache": not cache.cache, "library_file": zeroconf.__file__, "cache_file": zeroconf._cache.__file__}), flush=True)
raise SystemExit(0)
'''
    data = marshal.dumps(compile(source, "onemouse_lgpl_relink_probe.py", "exec", dont_inherit=True))
    return ("onemouse_lgpl_relink_probe", zlib.compress(data, 6), len(data), 1, b"s")


def recompose(base: bytes, source_dir: Path, probe: bool):
    if digest(base) != BASE_SHA256:
        raise ValueError("Input hash differs from the exact OneMouse 1.6.2 object-code base.")
    prefix, entries, py_version, py_library = read_archive(base)
    pyz_entries = [entry for entry in entries if entry[4] == b"z"]
    if len(pyz_entries) != 1:
        raise ValueError("Expected exactly one embedded PYZ archive.")
    pyz, source_hashes = replacement_pyz(uncompressed(pyz_entries[0]), source_dir)
    changed_entries = []
    native_removed = []
    probe_added = False
    untouched = []
    for entry in entries:
        name = entry[0]
        if name.replace("\\", "/").startswith(LIBRARY + "/"):
            # Use the supported pure-Python implementation for user-modified
            # zeroconf, rather than retaining stale Cython extension modules.
            native_removed.append(name)
            continue
        if entry[4] == b"z":
            changed_entries.append((name, zlib.compress(pyz, 6) if entry[3] else pyz, len(pyz), entry[3], b"z"))
            continue
        if probe and name == "backend_launcher":
            changed_entries.append(probe_entry())
            probe_added = True
        changed_entries.append(entry)
        untouched.append(name)
    if probe and not probe_added:
        raise ValueError("Could not locate the app entry point for the isolated import probe.")
    output = encode_archive(prefix, changed_entries, py_version, py_library)
    # Verify reconstruction itself and invariant object-code bytes before writing.
    out_prefix, out_entries, _, _ = read_archive(output)
    out_by_name = {entry[0]: entry for entry in out_entries}
    original_by_name = {entry[0]: entry for entry in entries}
    if out_prefix != prefix or any(out_by_name[name] != original_by_name[name] for name in untouched):
        raise ValueError("An unrelated object-code or bootloader payload changed.")
    return output, {"base_sha256": digest(base), "output_sha256": digest(output), "probe": probe,
                    "unchanged_archive_entries": len(untouched), "removed_native_entries": native_removed,
                    "replacement_source_sha256": source_hashes, "bootloader_unchanged": True}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    base_group = parser.add_mutually_exclusive_group(required=True)
    base_group.add_argument("--base", type=Path, help="Exact unsigned OneMouse 1.6.2 backend object-code EXE")
    base_group.add_argument("--base-manifest", type=Path, help="Combine and verify the two supplied object-code parts")
    parser.add_argument("--zeroconf-dir", type=Path, required=True, help="Your extracted/modified src/zeroconf directory")
    parser.add_argument("--output", type=Path, required=True, help="A new filename outside installed WindowsApps")
    parser.add_argument("--probe", action="store_true", help="Import/data-only diagnostic copy; does not start the app")
    args = parser.parse_args()
    if sys.implementation.name != "cpython" or sys.version_info[:2] != (3, 11) or struct.calcsize("P") != 8:
        parser.error("Use 64-bit CPython 3.11. The backend has CPython 3.11 object code.")
    if args.output.exists() or args.output.with_suffix(args.output.suffix + ".json").exists():
        parser.error("Output/report already exists. Choose a new filename; existing files are never overwritten.")
    if "windowsapps" in (part.lower() for part in args.output.resolve().parts):
        parser.error("Choose an output outside WindowsApps. Installed Store packages are not modified.")
    base = args.base.read_bytes() if args.base else base_from_manifest(args.base_manifest)
    output, report = recompose(base, args.zeroconf_dir, args.probe)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("xb") as stream:
        stream.write(output)
    with args.output.with_suffix(args.output.suffix + ".json").open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"output": str(args.output), "bytes": len(output), **report}, indent=2))


if __name__ == "__main__":
    main()
